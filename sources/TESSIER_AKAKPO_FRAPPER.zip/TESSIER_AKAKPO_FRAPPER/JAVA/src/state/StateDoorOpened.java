package state;

public class StateDoorOpened implements StateDoor {

	@Override
	public void opening() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void closing() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void closed() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void opened() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void blocked() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void recovery() {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void getState() {
		System.out.println("Etat porte ouverte");
		
	}

}
